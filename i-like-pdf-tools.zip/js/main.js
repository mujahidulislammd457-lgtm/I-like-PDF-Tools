const tools = [
  "Merge PDFs","Split PDF (extract pages)","Rotate PDF pages","Convert PDF → Word (DOCX)",
  "Add Watermark to PDF","JPG/PNG → PDF","Convert PDF → PNG images","Convert PDF → Excel (XLSX)",
  "PDF → JPG (page export using pdfjs)","Extract images (basic)","Basic Compress (naive rasterize + rebuild)",
  "Reduce PDF Size (advanced compression)","Add Signature (draw & place)","Convert TXT → PDF",
  "Resize Pages (change page dimensions)","Download metadata / info","Extract Text (to TXT/Word)",
  "Remove Pages (delete selected pages)","Reorder Pages (drag & drop page order)","Add Page Numbers (header/footer)",
  "PDF to HTML (convert PDF pages to web format)","Merge Bookmarks / Table of Contents (basic)",
  "Flatten Form Fields (make filled forms static)","Add / Remove Password (simple password protect/unprotect)",
  "Convert to PDF/A (best-effort client-side wrapper)","OCR (text recognition using tesseract.js WASM - client-side)",
  "Annotate PDF (draw/highlight/comment locally)","Repair (basic file validation & quick-fix suggestions)",
  "Optimize Fonts (remove unused / subset fonts)","Convert to Grayscale PDF","Crop Pages (select area of a page)",
  "Add Header & Footer Text","Add Stamp (custom image or text stamp)","Remove Metadata (strip hidden data)",
  "Redact Text (permanently hide sensitive content)","Replace Text in PDF","Insert Blank Page(s)",
  "Export Attachments from PDF","Import Attachments to PDF","Split PDF by File Size","Convert PDF → EPUB",
  "Convert PDF → TIFF images","Sign with Digital Certificate","Verify Digital Signature","Merge Interactive Forms",
  "Extract Form Fields","Create Fillable Form","Fill Form Fields","Compress Embedded Images","Image Compressor"
];

const grid = document.getElementById("toolsGrid");
tools.forEach(tool => {
  const card = document.createElement("div");
  card.className = "tool-card";
  card.innerHTML = `
    <h2>${tool}</h2>
    <p>This tool helps you ${tool.toLowerCase()} easily.</p>
    <button onclick="alert('Redirecting to ${tool}')">Open</button>
  `;
  grid.appendChild(card);
});

// Search functionality
document.getElementById("search").addEventListener("input", function() {
  const query = this.value.toLowerCase();
  const cards = document.querySelectorAll(".tool-card");
  cards.forEach(card => {
    const text = card.querySelector("h2").innerText.toLowerCase();
    card.style.display = text.includes(query) ? "block" : "none";
  });
});

// Generate long article with repeated tool names
const article = [];
for (let i = 0; i < 200; i++) {
  article.push(`I Like PDF Tools offers great functionality like ${tools[i % tools.length]}.`);
}
document.getElementById("longArticle").innerText = article.join(" ");
